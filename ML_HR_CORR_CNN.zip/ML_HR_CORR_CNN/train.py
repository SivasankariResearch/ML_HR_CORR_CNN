**7. train.py** (Model training and evaluation)
```python
from dataset import preprocess_data
from cnn_feature_extractor import build_cnn_feature_extractor
from sample_optimization import optimize_samples
from fcn_classifier import build_fcn_classifier
import tensorflow as tf

dataset_path = "path_to_dataset"
X_train, X_test, y_train, y_test, label_encoder = preprocess_data(dataset_path)

cnn_extractor = build_cnn_feature_extractor()
feature_maps = cnn_extractor.predict(X_train)
X_train_optimized, y_train_optimized = optimize_samples(feature_maps, y_train)

fcn_classifier = build_fcn_classifier()
fcn_classifier.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])

history = fcn_classifier.fit(X_train_optimized, y_train_optimized, epochs=20, batch_size=32, validation_data=(X_te
