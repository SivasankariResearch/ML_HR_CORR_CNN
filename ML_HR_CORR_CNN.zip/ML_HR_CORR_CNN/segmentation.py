**2. segmentation.py** (Performs word segmentation)
```python
import numpy as np
import cv2

def segment_words(image):
gray = cv2.threshold(image, 128, 255, cv2.THRESH_BINARY_INV)[1]
h_proj = np.sum(gray, axis=1)
    lines = np.where(h_proj>np.mean(h_proj) / 2)[0]
segmented_words = []
for line in np.split(gray, np.where(np.diff(lines) > 5)[0] + 1):
v_proj = np.sum(line, axis=0)
        words = np.where(v_proj>np.mean(v_proj) / 2)[0]
        for word in np.split(line, np.where(np.diff(words) > 5)[0] + 1):
segmented_words.append(cv2.resize(word, (128, 32)))
    return segmented_words
```
