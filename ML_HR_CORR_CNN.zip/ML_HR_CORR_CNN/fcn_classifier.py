**6. fcn_classifier.py** (Fully Convolutional Network for classification)
```python
import tensorflow as tf
from tensorflow.keras import layers

def build_fcn_classifier(input_shape=(256,)):
    model = tf.keras.Sequential([
layers.Dense(128, activation="relu", input_shape=input_shape),
layers.Dropout(0.3),
layers.Dense(10, activation="softmax")  # Adjust number of classes
    ])
    return model
```
