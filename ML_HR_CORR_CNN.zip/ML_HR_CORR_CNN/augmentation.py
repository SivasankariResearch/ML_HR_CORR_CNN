**3. augmentation.py** (Handles image augmentation)
```python
import tensorflow as tf
datagen = tf.keras.preprocessing.image.ImageDataGenerator(
rotation_range=10,
width_shift_range=0.1,
height_shift_range=0.1,
shear_range=0.1,
zoom_range=0.1,
fill_mode="nearest"
)
```
