**4. cnn_feature_extractor.py** (CNN-based feature extraction)
```python
import tensorflow as tf
from tensorflow.keras import layers

def build_cnn_feature_extractor(input_shape=(128, 32, 1)):
    model = tf.keras.Sequential([
layers.Conv2D(32, (3,3), activation="relu", padding="same", input_shape=input_shape),
layers.MaxPooling2D((2,2)),
layers.Conv2D(64, (3,3), activation="relu", padding="same"),
layers.MaxPooling2D((2,2)),
layers.Conv2D(128, (3,3), activation="relu", padding="same"),
layers.MaxPooling2D((2,2)),
layers.Flatten(),
layers.Dense(256, activation="relu")
    ])
    return model
```
